import json
from plot import plot
from sample import leads

def lambda_handler(event, context):

    leads = event['waveform']

    if (leads == None):
        return {
            'statusCode': 400,
            'body': json.dumps(
                {
                'message': 'No waveform data provided'
            })
        }

    try:
        generated_chart = plot(leads)
        return {
            "statusCode": 200,
            "headers": {
                "Content-Type": "image/svg+xml"
            },
            "body": generated_chart
        }
    except:
        return {
            'statusCode': 400,
            'body': json.dumps(
                {
                'message': 'Error generating chart'
            })
        }